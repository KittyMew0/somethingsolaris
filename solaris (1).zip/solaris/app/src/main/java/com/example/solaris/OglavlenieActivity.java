package com.example.solaris;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.solaris.R;

public class OglavlenieActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oglavlenie);
    }
    public void start_m1(View v) {
        Intent intent = new Intent(this, Module1Activity.class);
        startActivity(intent);

    }
    public void ogl_kurs(View v) {
        Intent intent = new Intent(this, KursActivity.class);
        startActivity(intent);

    }
}