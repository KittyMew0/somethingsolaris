package com.example.solaris;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.solaris.OglavlenieActivity;
import com.example.solaris.R;

public class KursActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kurs);
    }
    public void start_ogl(View v) {
        Intent intent = new Intent(this, OglavlenieActivity.class);
        startActivity(intent);
    }
    public void kurs_menu(View v) {
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
    }
}