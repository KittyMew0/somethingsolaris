package com.example.solaris;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.solaris.R;

public class Module1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module1);
    }
    public void m1_kurs(View v) {
        Intent intent = new Intent(this, KursActivity.class);
        startActivity(intent);

    }
}